#ifndef PARTB_H
#define PARTB_H

void partb(int A[100][100], int B[100][100], int C[100][100],
		   int mA, int nA, int mB,
		   int nB, int mC, int nC);

void gold(int A[100][100], int B[100][100], int C[100][100],
			 int mA, int nA, int mB,
			 int nB, int mC, int nC);

#endif
